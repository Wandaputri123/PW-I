package wanda.putri;
import java.util.Scanner;
public class WandaPutri {
    public static void main(String[] args) {
    String Nama;
    long NIM;
    String Cita2;
    
    Scanner inputan = new Scanner(System.in);
    System.out.println("masukkan nama = ");
    Nama = inputan.nextLine();
    System.out.println("masukkan NIM = ");
    NIM = inputan.nextLong();
    System.out.println("masukkan cita-cita = ");
    Cita2 = inputan.next();
    
    System.out.println("----DAFTAR NAMA----");
    System.out.println("Nama = "+Nama);
    System.out.println("NIM = "+NIM);
    System.out.println("Cita-Cita = "+ Cita2);
    }
}
